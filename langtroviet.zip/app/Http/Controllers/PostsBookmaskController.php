<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PostsBookmaskController extends Controller
{
    
}
