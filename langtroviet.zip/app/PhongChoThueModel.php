<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PhongChoThueModel extends Model
{
    protected $table = "phongchothue";
}
